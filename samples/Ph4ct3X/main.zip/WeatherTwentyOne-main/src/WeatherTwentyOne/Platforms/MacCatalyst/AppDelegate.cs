﻿using Foundation;
using Microsoft.Maui;

namespace WeatherTwentyOne
{
	[Register("AppDelegate")]
	public class AppDelegate : MauiUIApplicationDelegate<Startup>
	{
	}
}