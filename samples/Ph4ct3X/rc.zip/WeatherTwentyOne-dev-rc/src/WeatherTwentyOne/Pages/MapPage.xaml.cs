﻿namespace WeatherTwentyOne.Pages
{
    public partial class MapPage : ContentPage
    {
        public MapPage()
        {
            InitializeComponent(); 
        }
    }
}