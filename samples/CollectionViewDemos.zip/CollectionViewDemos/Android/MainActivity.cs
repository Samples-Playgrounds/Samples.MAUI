﻿using Android.App;
using Microsoft.Maui;

namespace CollectionViewDemos
{
	[Activity(Theme = "@style/Maui.SplashTheme", MainLauncher = true)]
	public class MainActivity : MauiAppCompatActivity
	{
	}
}