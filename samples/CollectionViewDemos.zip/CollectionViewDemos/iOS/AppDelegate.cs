﻿using Foundation;
using Microsoft.Maui;

namespace CollectionViewDemos
{
	[Register("AppDelegate")]
	public class AppDelegate : MauiUIApplicationDelegate<Startup>
	{
	}
}