﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StopwatchMaui.Models
{
    public class LapTime
    {
        public int LapNumber { get; set; }
        public string ElapsedTime { get; set; }
    }
}
