# stopwatch-maui
Sample stopwatch app written with .NET MAUI 6. This app was migrated from the <a href="https://github.com/anotherlab/stopwatch-xf" target="_blank">Xamarin.Forms version of the app</a>.

This sample project uses the Digital-7 font from <a href="http://www.styleseven.com/" target="_blank">Style-7</a>. The complete version of the typefaces used by this demo can be <a href="https://www.1001fonts.com/download/digital-7.zip" target="_blank">downloaded</a> from 1001fonts.com. 

The <a href="https://www.flaticon.com/free-icon/stopwatch_2055568?term=stopwatch&related_id=2055568" target="_blank">stopwatch</a> icon was made by <a href="https://www.flaticon.com/authors/freepik" target="_blank">Freepik</a> and is available from <a href="https://www.flaticon.com/" target="_blank">Flaticon.com</a>
