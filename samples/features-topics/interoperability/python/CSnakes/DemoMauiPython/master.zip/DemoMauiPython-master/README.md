# DemoMauiPython

Adding CSnakes to a demo MAUI App

![CleanShot 2025-01-22 at 17 39 07](https://github.com/user-attachments/assets/f6493e75-f1b4-4dbd-8a97-9a049fded92a)
