﻿namespace Sample.Issue_12291.PostNotifications;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
