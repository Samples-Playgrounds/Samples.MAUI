﻿namespace Sample.Issue_12291.PostNotifications;

public partial class App : Application
{
	public App()
	{
		InitializeComponent();

		MainPage = new AppShell();
	}
}
