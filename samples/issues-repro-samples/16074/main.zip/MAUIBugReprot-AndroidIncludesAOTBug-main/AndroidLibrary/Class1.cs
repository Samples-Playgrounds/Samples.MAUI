﻿namespace AndroidLibrary;

public class Class1
{
}
