﻿using Foundation;

namespace Sample.Issue_13446.SMS_Perimisions;

[Register("AppDelegate")]
public class AppDelegate : MauiUIApplicationDelegate
{
	protected override MauiApp CreateMauiApp() => MauiProgram.CreateMauiApp();
}
