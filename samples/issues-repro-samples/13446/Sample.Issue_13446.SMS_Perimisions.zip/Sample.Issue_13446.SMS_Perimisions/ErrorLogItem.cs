using System;
namespace Sample.Issue_13446.SMS_Perimisions
{
    public class ErrorLogItem
    {
        public DateTime DateTimeStamp
        {
            get;
            set;
        }

        public string Message
        {
            get;
            set;
        }
    }
}

