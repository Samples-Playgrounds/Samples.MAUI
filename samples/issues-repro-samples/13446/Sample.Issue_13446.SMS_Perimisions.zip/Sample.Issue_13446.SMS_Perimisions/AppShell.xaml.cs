﻿namespace Sample.Issue_13446.SMS_Perimisions;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
