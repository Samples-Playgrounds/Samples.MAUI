﻿namespace 中文;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
