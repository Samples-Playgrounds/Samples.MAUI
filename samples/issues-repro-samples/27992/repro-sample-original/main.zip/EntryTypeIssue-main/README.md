# EntryTypeIssue
Entry ReturnType Does Not Work Properly on Android and Triggers Completed Event Twice When Mapped Manually
