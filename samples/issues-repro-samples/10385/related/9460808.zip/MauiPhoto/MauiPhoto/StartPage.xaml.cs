namespace MauiPhoto;

public partial class StartPage : ContentPage
{
	public StartPage()
	{
		InitializeComponent();
	}
}