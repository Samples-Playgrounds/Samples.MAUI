namespace MauiPhoto;

public partial class OtherPage : ContentPage
{
	public OtherPage()
	{
		InitializeComponent();
	}
}