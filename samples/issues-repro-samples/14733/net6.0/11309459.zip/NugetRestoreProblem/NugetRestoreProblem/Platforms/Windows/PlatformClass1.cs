﻿namespace NugetRestoreProblem
{
  // All the code in this file is only included on Windows.
  public class PlatformClass1
  {
  }
}