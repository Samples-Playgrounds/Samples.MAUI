﻿
namespace TodoApp.Intefaces
{
    public interface IBackNavigationCancelled { }

}
