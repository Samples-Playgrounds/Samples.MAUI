﻿
namespace TodoApp.Data
{
    public class Note
    {
        public string Titulo { get; set; }
        public string Descricao { get; set; }
    }
}
