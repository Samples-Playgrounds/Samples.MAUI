# .NET MAUI Base64 Encoding/Decoding Image Sample
Sample code to demonstrate how to encode and decode Base64 images in .NET MAUI

Blog post van be found here: https://blog.verslu.is/maui/displaying-base64-encoded-images-dotnet-maui/
