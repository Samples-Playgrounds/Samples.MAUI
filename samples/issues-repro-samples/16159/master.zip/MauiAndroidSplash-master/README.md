# MauiAndroidSplash

Issue demonstrating that on Android the splashscreen svg file is not shown only the background is shown from the csprog file

This is a default template app with no changes

Issue can be demonstrated by building and running on an android device or emulator
