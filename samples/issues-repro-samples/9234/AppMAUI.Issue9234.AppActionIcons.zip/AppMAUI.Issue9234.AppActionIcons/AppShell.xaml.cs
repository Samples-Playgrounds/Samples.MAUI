﻿namespace AppMAUI.Issue9234.AppActionIcons;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
