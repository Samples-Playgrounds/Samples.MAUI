﻿using Foundation;

namespace AppMAUI.Issue9234.AppActionIcons;

[Register("AppDelegate")]
public class AppDelegate : MauiUIApplicationDelegate
{
	protected override MauiApp CreateMauiApp() => MauiProgram.CreateMauiApp();
}
