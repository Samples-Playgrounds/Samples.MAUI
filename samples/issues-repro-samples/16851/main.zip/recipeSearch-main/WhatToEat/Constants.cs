﻿using System;
namespace Recipes
{
    public static class Constants
    {
        public static string EdamamEndpoint = "search";
        public static string EdamamAppId = "59a10d27";
        public static string EdamamAppKey = "fde0aca98a8b17da057d521fcbde7d02";
    }
}
