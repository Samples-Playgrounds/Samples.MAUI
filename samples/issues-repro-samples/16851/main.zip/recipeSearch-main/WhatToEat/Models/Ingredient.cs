﻿namespace Recipes.Models
{
    public class Ingredient
    {
        public string IngredientItem { get; set; }
        public bool IngredientChecked { get; set; }
    }
}