﻿namespace ImageTest;

public partial class MainPage
{
    public MainPage()
    {
        InitializeComponent();
    }
}