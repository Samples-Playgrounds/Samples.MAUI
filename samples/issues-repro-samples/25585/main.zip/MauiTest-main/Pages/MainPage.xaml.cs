﻿namespace CleanApp.Pages
{
    public partial class MainPage : BasePage
    {

        public MainPage()
        {
            InitializeComponent();
        }

    }

}
