﻿namespace AppMAUI.SampleRepro17586;

public partial class App : Application
{
	public App()
	{
		InitializeComponent();

		MainPage = new AppShell();
	}
}
