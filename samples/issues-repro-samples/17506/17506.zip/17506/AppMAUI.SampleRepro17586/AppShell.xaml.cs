﻿namespace AppMAUI.SampleRepro17586;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
