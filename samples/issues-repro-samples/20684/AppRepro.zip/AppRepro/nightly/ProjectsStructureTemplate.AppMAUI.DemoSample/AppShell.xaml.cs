﻿namespace ProjectsStructureTemplate.AppMAUI.DemoSample;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
