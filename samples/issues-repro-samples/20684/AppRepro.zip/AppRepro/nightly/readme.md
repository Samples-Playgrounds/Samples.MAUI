# Nightly Builds

*   https://github.com/dotnet/maui/wiki/Nightly-Builds

```xml
```

```xml
<PackageReference Include="Microsoft.Maui.Controls" Version="$(MauiVersion)" />
<PackageReference Include="Microsoft.Maui.Controls.Compatibility" Version="$(MauiVersion)" />
```


*   https://learn.microsoft.com/en-us/visualstudio/msbuild/customize-by-directory

*   https://learn.microsoft.com/en-us/nuget/consume-packages/central-package-management

