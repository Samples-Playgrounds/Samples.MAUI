﻿namespace ProjectsStructureTemplate.AppMAUI.HybridBlazor.DemoSample;

public partial class MainPage : ContentPage
{
	public MainPage()
	{
		InitializeComponent();
	}
}
