﻿namespace ProjectsStructureTemplate.AppMAUI.HybridBlazor.DemoSample;

public partial class App : Application
{
	public App()
	{
		InitializeComponent();

		MainPage = new MainPage();
	}
}
