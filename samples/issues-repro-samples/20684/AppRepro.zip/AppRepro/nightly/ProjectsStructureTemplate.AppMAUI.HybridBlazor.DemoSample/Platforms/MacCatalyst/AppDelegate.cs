﻿using Foundation;

namespace ProjectsStructureTemplate.AppMAUI.HybridBlazor.DemoSample;

[Register("AppDelegate")]
public class AppDelegate : MauiUIApplicationDelegate
{
	protected override MauiApp CreateMauiApp() => MauiProgram.CreateMauiApp();
}
