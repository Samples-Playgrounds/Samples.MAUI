namespace AppMAUI.UserInterface.View.StopWatch;

public partial class 
										Page 
										: 
										ContentPage
{
	public 
										Page
										(											
										)
	{
		InitializeComponent();

		return;
	}
}