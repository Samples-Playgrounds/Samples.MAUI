namespace AppMAUI.UserInterface.Person.View;

public partial class 
										Page 
										: 
										ContentPage
{
	public 
										Page
										(											
										)
	{
		InitializeComponent();

		/*
		
		*/
		return;
	}
}