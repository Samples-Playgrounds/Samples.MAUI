namespace AppMAUI.UserInterface.DateTime.View;

public partial class 
										Page 
										: 
										ContentPage
{
	public 
										Page
										(											
										)
	{
		InitializeComponent();

		return;
	}
}