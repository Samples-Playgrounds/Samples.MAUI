namespace AppMAUI.UserInterface.Clock.View;

public partial class 
										Page 
										:
										ContentPage
{
	public 
										Page
										(											
										)
	{
		InitializeComponent();

		return;
	}
}