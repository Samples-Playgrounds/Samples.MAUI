using CommunityToolkit.Maui.Views;
namespace Toolkit;

public partial class NewPopup : Popup
{
	public NewPopup()
	{
		InitializeComponent();
	}
}