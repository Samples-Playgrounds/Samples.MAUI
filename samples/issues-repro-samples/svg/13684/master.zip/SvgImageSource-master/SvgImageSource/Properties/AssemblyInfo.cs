﻿using System.Reflection;
using System.Runtime.CompilerServices;


[assembly: InternalsVisibleTo("SvgImageSource.iOS")]
[assembly: InternalsVisibleTo("SvgImageSource.Droid")]
