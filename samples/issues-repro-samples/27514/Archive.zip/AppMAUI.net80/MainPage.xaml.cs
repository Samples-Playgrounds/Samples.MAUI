﻿namespace AppMAUI.net80;

public partial class MainPage : ContentPage
{
	int count = 0;

	public MainPage()
	{
		InitializeComponent();

        BindingContext = new ViewModel();
	}
}

