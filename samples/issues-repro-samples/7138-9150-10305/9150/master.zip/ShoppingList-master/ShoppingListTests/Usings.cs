global using NUnit.Framework;
global using ShoppingList.Model;
global using ShoppingList.Services; 
