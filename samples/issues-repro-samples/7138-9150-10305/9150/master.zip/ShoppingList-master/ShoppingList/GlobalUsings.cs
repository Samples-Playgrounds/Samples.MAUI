﻿global using System;
global using System.Collections.Generic;
global using System.Linq;
global using System.Text;
global using System.Threading.Tasks;
global using CommunityToolkit.Mvvm.ComponentModel; 
global using CommunityToolkit.Mvvm.Input;
global using SQLitePCL;
global using SQLite;
global using ShoppingList.Model;
global using ShoppingList.Services;
global using ShoppingList.ViewModels;
global using ShoppingList.Drawable;
global using ShoppingList.Controls;
global using SQLiteNetExtensions.Attributes;
global using CommunityToolkit.Diagnostics; 


