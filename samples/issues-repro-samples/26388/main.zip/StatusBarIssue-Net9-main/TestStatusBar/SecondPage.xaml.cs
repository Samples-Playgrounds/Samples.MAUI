﻿namespace TestStatusBar
{
    public partial class SecondPage : ContentPage
    {

        public SecondPage()
        {
            InitializeComponent();


        }

    }

}
