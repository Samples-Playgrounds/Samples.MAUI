﻿using Foundation;

namespace TabbarHandlerIssue.Views;

public partial class Page1 : BaseContentPage
{
	public Page1()
	{
		InitializeComponent();
		Console.WriteLine("Running Page1 Content: Message page");
	}
}
