﻿using Foundation;

namespace TabbarHandlerIssue.Views;

public partial class Page2 : BaseContentPage
{
	public Page2()
	{
		InitializeComponent();
        Console.WriteLine("Running Page2 Content: Leave page");
    }
}
