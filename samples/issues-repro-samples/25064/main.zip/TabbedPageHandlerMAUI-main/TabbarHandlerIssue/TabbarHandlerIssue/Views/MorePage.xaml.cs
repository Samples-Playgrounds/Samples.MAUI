﻿using Foundation;

namespace TabbarHandlerIssue.Views;

public partial class MorePage : BaseContentPage
{
	public MorePage()
	{
		InitializeComponent();
	}
}
