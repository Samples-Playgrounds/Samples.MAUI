﻿using Foundation;
namespace TabbarHandlerIssue.Views;

public partial class Page3 : BaseContentPage
{
	public Page3()
	{
		InitializeComponent();
        Console.WriteLine("Running Page3 Content: Appointment page");
    }
}
