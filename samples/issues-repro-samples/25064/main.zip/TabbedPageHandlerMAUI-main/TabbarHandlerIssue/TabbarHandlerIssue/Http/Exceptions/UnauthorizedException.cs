﻿using System;

namespace Core.Http
{
  public class UnauthorizedException : Exception
  {
  }
}
