﻿using System;

namespace Core.Http
{
  public class ServerNotFoundException : Exception
  {
  }
}
