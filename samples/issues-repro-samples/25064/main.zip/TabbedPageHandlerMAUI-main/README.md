# TabbedPageHandlerMAUI
Uploading a sample solution to reproduce the issue of TabbedPageHandler maui
