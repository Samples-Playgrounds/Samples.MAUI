﻿using Foundation;

namespace AppMAUI.Issue14729.PermissionsExternalStorage;

[Register("AppDelegate")]
public class AppDelegate : MauiUIApplicationDelegate
{
	protected override MauiApp CreateMauiApp() => MauiProgram.CreateMauiApp();
}
