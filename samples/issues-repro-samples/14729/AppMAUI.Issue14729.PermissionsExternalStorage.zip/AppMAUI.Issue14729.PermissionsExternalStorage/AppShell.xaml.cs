﻿namespace AppMAUI.Issue14729.PermissionsExternalStorage;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
