global using AppMAUI.mauiapp.net9._0;
global using AppMAUI.mauiapp.net9._0.Views;

// Static
global using static Microsoft.Maui.Graphics.Colors;
