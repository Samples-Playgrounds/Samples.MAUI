﻿namespace MauiBug_DeepLinkCrash;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
