# MauiBug_DeepLinkCrash

Reproduction project for https://github.com/dotnet/maui/issues/11684 in .NET MAUI
